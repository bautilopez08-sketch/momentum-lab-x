import OnboardingForm from "@/components/OnboardingForm";

export const metadata = {
  title: "Comenzar — Momentum Lab",
  description: "Contanos sobre tu empresa y te armamos un diagnóstico digital a medida.",
};

export default function OnboardingPage() {
  return <OnboardingForm />;
}
