import { BackgroundPaths } from "@/components/ui/background-paths";
import Navbar from "@/components/Navbar";
import ServicesSection from "@/components/ServicesSection";
import MethodologySection from "@/components/MethodologySection";
import TeamSection from "@/components/TeamSection";
import CasesSection from "@/components/CasesSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <BackgroundPaths
        title="Momentum Lab"
        subtitle="Transformamos empresas en líderes digitales. Consultoría estratégica con el rigor de UdeSA y la velocidad del mundo startup."
        ctaText="Comenzar ahora"
        ctaHref="/onboarding"
      />
      <ServicesSection />
      <MethodologySection />
      <TeamSection />
      <CasesSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
