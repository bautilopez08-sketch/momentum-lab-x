import FoundersPage from "@/components/FoundersPage";

export const metadata = {
  title: "Fundadores — Momentum Lab",
  description: "Conocé al equipo fundador de Momentum Lab, alumnos de UdeSA Negocios Digitales.",
};

export default function Founders() {
  return <FoundersPage />;
}
