"use client";

import { motion } from "framer-motion";
import type { Variants } from "framer-motion";
import { BarChart3, Workflow, Globe, ShieldCheck, BrainCircuit, Rocket } from "lucide-react";

const services = [
  {
    icon: BrainCircuit,
    title: "Estrategia Digital",
    description:
      "Diseñamos hojas de ruta de transformación digital adaptadas a cada empresa, alineando tecnología con objetivos de negocio.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Workflow,
    title: "Optimización de Procesos",
    description:
      "Identificamos cuellos de botella y automatizamos flujos de trabajo para liberar el potencial de tu equipo.",
    gradient: "from-violet-500 to-purple-500",
  },
  {
    icon: BarChart3,
    title: "Analítica & Data",
    description:
      "Convertimos datos en decisiones. Implementamos dashboards y modelos analíticos que impulsan el crecimiento.",
    gradient: "from-orange-500 to-red-500",
  },
  {
    icon: Globe,
    title: "Expansión Digital",
    description:
      "Desarrollamos presencia digital escalable: e-commerce, plataformas SaaS y ecosistemas digitales a medida.",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: ShieldCheck,
    title: "Gestión del Cambio",
    description:
      "Acompañamos a los equipos en la adopción tecnológica con programas de capacitación y change management.",
    gradient: "from-pink-500 to-rose-500",
  },
  {
    icon: Rocket,
    title: "Innovación & Producto",
    description:
      "Co-creamos nuevos productos digitales con metodologías ágiles, desde la validación de hipótesis hasta el lanzamiento.",
    gradient: "from-amber-500 to-yellow-500",
  },
];

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: [0.25, 0.1, 0.25, 1] },
  }),
};

export default function ServicesSection() {
  return (
    <section id="servicios" className="py-24 bg-neutral-50 dark:bg-neutral-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-sm font-semibold tracking-widest text-blue-600 uppercase mb-4">
            Lo que hacemos
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-6">
            Servicios de{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
              Transformación
            </span>
          </h2>
          <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
            Combinamos visión estratégica con ejecución técnica para llevar a tu empresa al
            siguiente nivel digital.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="group relative bg-white dark:bg-neutral-800 rounded-2xl p-8 shadow-sm hover:shadow-lg transition-shadow duration-300 border border-neutral-200/80 dark:border-neutral-700/80 overflow-hidden"
              >
                <div
                  className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${service.gradient} opacity-5 rounded-full translate-x-8 -translate-y-8 group-hover:opacity-10 transition-opacity duration-300`}
                />
                <div
                  className={`inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br ${service.gradient} mb-6`}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-neutral-900 dark:text-white mb-3">
                  {service.title}
                </h3>
                <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
