"use client";

import { motion } from "framer-motion";
import { Link2, GraduationCap, Users } from "lucide-react";
import { useRouter } from "next/navigation";
import Image from "next/image";

const team = [
  {
    name: "Valentina Torres",
    role: "Strategy & Digital Transformation",
    bio: "Especialista en estrategia digital con foco en retail y consumo masivo.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
  {
    name: "Matías Herrera",
    role: "Data Analytics & BI",
    bio: "Experto en analítica avanzada y modelado de datos para decisiones de negocio.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
  {
    name: "Lucía Fernández",
    role: "Product & UX Design",
    bio: "Diseñadora de experiencias digitales centradas en el usuario y la conversión.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
  {
    name: "Ignacio Méndez",
    role: "Tech & Automation",
    bio: "Arquitecto de soluciones cloud y automatización de procesos empresariales.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
  {
    name: "Sofía Ramírez",
    role: "Change Management",
    bio: "Facilitadora de transformaciones organizacionales y adopción tecnológica.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
  {
    name: "Diego Castillo",
    role: "Growth & Marketing Digital",
    bio: "Growth hacker especializado en adquisición y retención en canales digitales.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    linkedin: "#",
  },
];

export default function TeamSection() {
  const router = useRouter();
  return (
    <section id="equipo" className="py-24 bg-neutral-50 dark:bg-neutral-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-sm font-semibold tracking-widest text-blue-600 uppercase mb-4">
            El equipo
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-6">
            Alumnos de{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
              UdeSA
            </span>
          </h2>
          <div className="flex items-center justify-center gap-2 mb-6">
            <GraduationCap className="w-5 h-5 text-blue-600" />
            <p className="text-neutral-600 dark:text-neutral-400 font-medium">
              Negocios Digitales · Universidad de San Andrés
            </p>
          </div>
          <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
            Un equipo multidisciplinario de jóvenes profesionales que combina rigor académico
            con la energía y agilidad del mundo startup.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member, i) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="group bg-white dark:bg-neutral-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-neutral-200/80 dark:border-neutral-700/80"
            >
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={member.image}
                  alt={member.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <a
                  href={member.linkedin}
                  className="absolute bottom-4 right-4 w-9 h-9 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center text-white hover:bg-blue-600 transition-colors duration-200"
                >
                  <Link2 className="w-4 h-4" />
                </a>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-lg text-neutral-900 dark:text-white mb-1">
                  {member.name}
                </h3>
                <p className="text-sm font-medium text-blue-600 dark:text-blue-400 mb-3">
                  {member.role}
                </p>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {member.bio}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA to founders page */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <button
            onClick={() => router.push("/fundadores")}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border-2 border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 font-semibold text-sm hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:border-blue-400 dark:hover:border-blue-600 transition-all duration-200 hover:-translate-y-0.5"
          >
            <Users className="w-4 h-4" />
            Conocé a los 7 fundadores →
          </button>
        </motion.div>
      </div>
    </section>
  );
}
