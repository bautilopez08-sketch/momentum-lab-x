"use client";

import { motion } from "framer-motion";
import { Search, Lightbulb, Code2, TrendingUp } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Search,
    title: "Diagnóstico",
    description:
      "Analizamos en profundidad el estado digital actual de tu empresa, identificando oportunidades y brechas tecnológicas.",
    color: "text-blue-600",
    bg: "bg-blue-50 dark:bg-blue-950/40",
    border: "border-blue-200 dark:border-blue-800",
  },
  {
    number: "02",
    icon: Lightbulb,
    title: "Estrategia",
    description:
      "Diseñamos un plan de transformación personalizado con objetivos claros, KPIs y hitos medibles.",
    color: "text-violet-600",
    bg: "bg-violet-50 dark:bg-violet-950/40",
    border: "border-violet-200 dark:border-violet-800",
  },
  {
    number: "03",
    icon: Code2,
    title: "Ejecución",
    description:
      "Implementamos soluciones de forma ágil, en sprints iterativos con feedback continuo y ajuste de ruta.",
    color: "text-orange-600",
    bg: "bg-orange-50 dark:bg-orange-950/40",
    border: "border-orange-200 dark:border-orange-800",
  },
  {
    number: "04",
    icon: TrendingUp,
    title: "Escalado",
    description:
      "Medimos resultados, optimizamos lo que funciona y escalamos las iniciativas con mayor impacto en el negocio.",
    color: "text-green-600",
    bg: "bg-green-50 dark:bg-green-950/40",
    border: "border-green-200 dark:border-green-800",
  },
];

export default function MethodologySection() {
  return (
    <section id="metodologia" className="py-24 bg-white dark:bg-neutral-950">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <span className="inline-block text-sm font-semibold tracking-widest text-blue-600 uppercase mb-4">
              Cómo trabajamos
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-6">
              Una metodología{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
                probada
              </span>
            </h2>
            <p className="text-lg text-neutral-600 dark:text-neutral-400 mb-8 leading-relaxed">
              Nacidos en las aulas de UdeSA Negocios Digitales, llevamos el rigor académico y
              la mentalidad emprendedora a cada proyecto. Nuestro proceso combina el pensamiento
              estratégico con la velocidad de ejecución de las mejores startups.
            </p>
            <div className="flex items-center gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-neutral-900 dark:text-white">30+</div>
                <div className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">Proyectos</div>
              </div>
              <div className="w-px h-12 bg-neutral-200 dark:bg-neutral-700" />
              <div className="text-center">
                <div className="text-4xl font-bold text-neutral-900 dark:text-white">95%</div>
                <div className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">Satisfacción</div>
              </div>
              <div className="w-px h-12 bg-neutral-200 dark:bg-neutral-700" />
              <div className="text-center">
                <div className="text-4xl font-bold text-neutral-900 dark:text-white">3x</div>
                <div className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">ROI Promedio</div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-4">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, x: 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.12, duration: 0.6 }}
                  className={`flex gap-5 p-5 rounded-2xl border ${step.bg} ${step.border} transition-transform duration-200 hover:-translate-y-0.5`}
                >
                  <div className={`flex-shrink-0 w-12 h-12 rounded-xl ${step.bg} border ${step.border} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${step.color}`} />
                  </div>
                  <div>
                    <div className={`text-xs font-bold ${step.color} mb-1 tracking-widest`}>
                      PASO {step.number}
                    </div>
                    <h3 className="font-bold text-neutral-900 dark:text-white mb-1">
                      {step.title}
                    </h3>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
