"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, Building2, ShoppingBag, Factory, Stethoscope } from "lucide-react";
import Image from "next/image";

const cases = [
  {
    icon: ShoppingBag,
    industry: "Retail",
    title: "Digitalización completa de una cadena de 40 tiendas",
    description:
      "Implementamos un sistema omnicanal que integró el e-commerce con el punto de venta físico, logrando un incremento del 180% en ventas online.",
    metrics: [
      { label: "Incremento en ventas online", value: "+180%" },
      { label: "Reducción de costos operativos", value: "-35%" },
    ],
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop",
    color: "from-orange-500 to-amber-500",
  },
  {
    icon: Factory,
    industry: "Manufactura",
    title: "Automatización de procesos en planta industrial",
    description:
      "Diseñamos e implementamos un sistema de automatización que redujo los tiempos de producción y mejoró el control de calidad con IA.",
    metrics: [
      { label: "Eficiencia productiva", value: "+60%" },
      { label: "Tiempo de entrega", value: "-40%" },
    ],
    image: "https://images.unsplash.com/photo-1565610222536-ef125047083b?w=600&h=400&fit=crop",
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: Stethoscope,
    industry: "Salud",
    title: "Plataforma digital para clínica privada",
    description:
      "Desarrollamos un ecosistema digital de turnos, telemedicina y gestión de historia clínica que transformó la experiencia del paciente.",
    metrics: [
      { label: "Satisfacción del paciente", value: "+92%" },
      { label: "Carga administrativa", value: "-50%" },
    ],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop",
    color: "from-green-500 to-emerald-500",
  },
  {
    icon: Building2,
    industry: "Servicios Financieros",
    title: "Dashboard de inteligencia de negocios para fintech",
    description:
      "Construimos una plataforma analítica en tiempo real que permite a los ejecutivos tomar decisiones basadas en datos con métricas actualizadas al instante.",
    metrics: [
      { label: "Velocidad de decisiones", value: "10x" },
      { label: "ROI en el primer año", value: "4.2x" },
    ],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
    color: "from-violet-500 to-purple-500",
  },
];

export default function CasesSection() {
  return (
    <section id="casos" className="py-24 bg-white dark:bg-neutral-950">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-sm font-semibold tracking-widest text-blue-600 uppercase mb-4">
            Resultados reales
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-6">
            Casos de{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
              Éxito
            </span>
          </h2>
          <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
            Empresas de distintas industrias que apostaron por la transformación digital y
            obtuvieron resultados medibles.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {cases.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                className="group bg-neutral-50 dark:bg-neutral-800/50 rounded-2xl overflow-hidden border border-neutral-200/80 dark:border-neutral-700/80 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className={`absolute top-4 left-4 flex items-center gap-2 bg-gradient-to-r ${item.color} text-white text-xs font-bold px-3 py-1.5 rounded-full`}>
                    <Icon className="w-3 h-3" />
                    {item.industry}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-bold text-xl text-neutral-900 dark:text-white mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {item.title}
                    <ArrowUpRight className="inline ml-1 w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                  <p className="text-neutral-600 dark:text-neutral-400 mb-5 leading-relaxed text-sm">
                    {item.description}
                  </p>
                  <div className="flex gap-6">
                    {item.metrics.map((metric) => (
                      <div key={metric.label}>
                        <div className={`text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${item.color}`}>
                          {metric.value}
                        </div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                          {metric.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
