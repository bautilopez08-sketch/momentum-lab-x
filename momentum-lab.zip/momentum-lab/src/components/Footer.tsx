"use client";

import { Zap, Link2, Globe, X } from "lucide-react";

export default function Footer() {
  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-neutral-900 dark:bg-neutral-950 text-white py-16 border-t border-neutral-800">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 font-bold text-xl mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-violet-600 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              Momentum<span className="text-blue-400">Lab</span>
            </div>
            <p className="text-neutral-400 text-sm leading-relaxed max-w-xs">
              Consultora de transformación digital fundada por alumnos de UdeSA Negocios Digitales.
              Impulsamos el futuro de las empresas argentinas.
            </p>
            <div className="flex gap-3 mt-6">
              <a
                href="#"
                className="w-9 h-9 bg-neutral-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <Link2 className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-9 h-9 bg-neutral-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <Globe className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-9 h-9 bg-neutral-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-neutral-200">Servicios</h4>
            <ul className="space-y-2 text-sm text-neutral-400">
              {["Estrategia Digital", "Optimización de Procesos", "Analítica & Data", "Expansión Digital", "Gestión del Cambio"].map((s) => (
                <li key={s}>
                  <button
                    onClick={() => scrollTo("#servicios")}
                    className="hover:text-white transition-colors text-left"
                  >
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-neutral-200">Empresa</h4>
            <ul className="space-y-2 text-sm text-neutral-400">
              {[
                { label: "Metodología", href: "#metodologia" },
                { label: "Equipo", href: "#equipo" },
                { label: "Casos de Éxito", href: "#casos" },
                { label: "Contacto", href: "#contacto" },
              ].map((l) => (
                <li key={l.href}>
                  <button
                    onClick={() => scrollTo(l.href)}
                    className="hover:text-white transition-colors"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-neutral-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-neutral-500">
          <p>© 2025 Momentum Lab. Todos los derechos reservados.</p>
          <p className="flex items-center gap-1">
            Hecho con
            <span className="text-red-500 mx-1">♥</span>
            por alumnos de{" "}
            <span className="text-neutral-300 ml-1 font-medium">UdeSA</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
