"use client";

import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { ArrowLeft, Link2, Zap } from "lucide-react";
import { TeamSection } from "@/components/ui/team-section-1";
import { Button } from "@/components/ui/button";

const founders = [
  {
    name: "Felipe Escandón",
    designation: "Co-Founder & Strategy",
    imageSrc:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Faustino Olazagasti",
    designation: "Co-Founder & Product",
    imageSrc:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Francisco Sánchez",
    designation: "Co-Founder & Tech",
    imageSrc:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Lautaro Zayat",
    designation: "Co-Founder & Data",
    imageSrc:
      "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Nicolás Los Daneri",
    designation: "Co-Founder & Growth",
    imageSrc:
      "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Santiago Velázquez",
    designation: "Co-Founder & Operations",
    imageSrc:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
  {
    name: "Bautista López",
    designation: "Co-Founder & Design",
    imageSrc:
      "https://images.unsplash.com/photo-1513910367299-bce8d8a0ebf6?w=400&h=400&fit=crop&crop=face",
    socialLinks: [{ icon: Link2, href: "#" }],
  },
];

function FloatingPaths({ position }: { position: number }) {
  const paths = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    d: `M-${380 - i * 5 * position} -${189 + i * 6}C-${380 - i * 5 * position} -${189 + i * 6} -${312 - i * 5 * position} ${216 - i * 6} ${152 - i * 5 * position} ${343 - i * 6}C${616 - i * 5 * position} ${470 - i * 6} ${684 - i * 5 * position} ${875 - i * 6} ${684 - i * 5 * position} ${875 - i * 6}`,
    width: 0.5 + i * 0.03,
  }));
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <svg className="w-full h-full text-slate-900 dark:text-white opacity-[0.03]" viewBox="0 0 696 316" fill="none">
        {paths.map((p) => (
          <motion.path
            key={p.id}
            d={p.d}
            stroke="currentColor"
            strokeWidth={p.width}
            initial={{ pathLength: 0.3, opacity: 0.6 }}
            animate={{ pathLength: 1, opacity: [0.3, 0.6, 0.3], pathOffset: [0, 1, 0] }}
            transition={{ duration: 22 + p.id * 0.4, repeat: Infinity, ease: "linear" }}
          />
        ))}
      </svg>
    </div>
  );
}

export default function FoundersPage() {
  const router = useRouter();

  return (
    <div className="relative min-h-screen bg-white dark:bg-neutral-950 overflow-hidden">
      <FloatingPaths position={1} />
      <FloatingPaths position={-1} />

      {/* navbar */}
      <header className="relative z-10 flex items-center justify-between px-6 py-5 border-b border-neutral-100 dark:border-neutral-800">
        <button
          onClick={() => router.push("/")}
          className="flex items-center gap-2 font-bold text-lg text-neutral-900 dark:text-white"
        >
          <div className="w-7 h-7 bg-gradient-to-br from-blue-600 to-violet-600 rounded-lg flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          Momentum<span className="text-blue-600">Lab</span>
        </button>
        <Button
          variant="ghost"
          onClick={() => router.push("/")}
          className="gap-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-white text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Button>
      </header>

      {/* hero banner */}
      <div className="relative z-10 text-center pt-16 pb-4 px-4">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <span className="inline-block text-xs font-semibold tracking-widest text-blue-600 uppercase mb-4 bg-blue-50 dark:bg-blue-950/40 px-3 py-1.5 rounded-full border border-blue-100 dark:border-blue-900">
            UdeSA · Negocios Digitales
          </span>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tighter text-neutral-900 dark:text-white mb-4">
            Los que hacen{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
              posible
            </span>{" "}
            el momentum
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 max-w-xl mx-auto text-base md:text-lg">
            Siete estudiantes de UdeSA con una misión: transformar la forma en que las empresas
            argentinas adoptan lo digital.
          </p>
        </motion.div>
      </div>

      {/* team section */}
      <motion.div
        initial={{ opacity: 0, y: 32 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="relative z-10"
      >
        <TeamSection
          title="FOUNDERS"
          description="Un equipo multidisciplinario que combina estrategia, tecnología, datos y diseño para llevar la transformación digital a las empresas que lo necesitan."
          members={founders}
          logo={
            <span className="flex items-center gap-1.5 text-lg font-bold">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-600 to-violet-600 rounded-md flex items-center justify-center">
                <Zap className="w-3 h-3 text-white" />
              </div>
              <span className="text-neutral-900 dark:text-white">
                Momentum<span className="text-blue-600">Lab</span>
              </span>
            </span>
          }
          className="bg-transparent dark:bg-transparent"
        />
      </motion.div>

      {/* cta footer */}
      <div className="relative z-10 text-center py-16 px-4 border-t border-neutral-100 dark:border-neutral-800">
        <p className="text-neutral-500 dark:text-neutral-400 mb-6 text-sm">
          ¿Querés trabajar con nosotros?
        </p>
        <Button
          onClick={() => router.push("/onboarding")}
          className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white border-0 px-8 py-3 rounded-xl text-sm font-semibold"
        >
          Empezá tu diagnóstico gratuito →
        </Button>
      </div>
    </div>
  );
}
