"use client";

import { motion } from "framer-motion";
import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "Momentum Lab no solo nos entregó una solución tecnológica, nos ayudaron a cambiar la mentalidad de todo nuestro equipo directivo. El impacto fue cultural y operacional.",
    author: "Carolina Vega",
    role: "CEO, GrupoVega Retail",
    initials: "CV",
    color: "bg-blue-600",
  },
  {
    quote:
      "Lo que más valoramos fue su enfoque práctico. Nos presentaron un diagnóstico honesto y un plan ejecutable. En 6 meses ya teníamos resultados concretos.",
    author: "Roberto Almeida",
    role: "Director de Operaciones, TechMed SA",
    initials: "RA",
    color: "bg-violet-600",
  },
  {
    quote:
      "Jóvenes con una madurez profesional impresionante. Combinan el conocimiento académico con la agilidad de quienes viven en el mundo digital. Altamente recomendables.",
    author: "Patricia Solano",
    role: "Gerente General, Solano & Asociados",
    initials: "PS",
    color: "bg-orange-600",
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-24 bg-neutral-50 dark:bg-neutral-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-sm font-semibold tracking-widest text-blue-600 uppercase mb-4">
            Testimonios
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white">
            Lo que dicen{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-violet-600">
              nuestros clientes
            </span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.author}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.6 }}
              className="bg-white dark:bg-neutral-800 rounded-2xl p-8 shadow-sm border border-neutral-200/80 dark:border-neutral-700/80 flex flex-col"
            >
              <Quote className="w-8 h-8 text-blue-600/30 mb-4" />
              <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed flex-1 mb-6 italic">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 ${t.color} rounded-full flex items-center justify-center text-white font-bold text-sm`}
                >
                  {t.initials}
                </div>
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white text-sm">
                    {t.author}
                  </div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
