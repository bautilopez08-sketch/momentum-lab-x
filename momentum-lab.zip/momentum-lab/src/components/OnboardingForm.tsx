"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import {
  Building2,
  Globe2,
  BarChart3,
  Users,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Zap,
  Target,
  TrendingUp,
  ShoppingBag,
  Heart,
  Factory,
  GraduationCap,
  Landmark,
  Truck,
  Utensils,
  MoreHorizontal,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// ─── types ───────────────────────────────────────────────────────────────────

type FormData = {
  companyName: string;
  country: string;
  industry: string;
  companySize: string;
  digitalMaturity: string;
  mainGoal: string;
  contactName: string;
  contactEmail: string;
};

// ─── static data ─────────────────────────────────────────────────────────────

const COUNTRIES = [
  "Argentina", "Brasil", "Chile", "Colombia", "México",
  "Perú", "Uruguay", "Paraguay", "Ecuador", "Bolivia",
  "Venezuela", "España", "Estados Unidos", "Otro",
];

const INDUSTRIES = [
  { label: "Retail", icon: ShoppingBag },
  { label: "Salud", icon: Heart },
  { label: "Manufactura", icon: Factory },
  { label: "Educación", icon: GraduationCap },
  { label: "Servicios Financieros", icon: Landmark },
  { label: "Logística", icon: Truck },
  { label: "Gastronomía", icon: Utensils },
  { label: "Tecnología", icon: Zap },
  { label: "Consultoría", icon: BarChart3 },
  { label: "Otro", icon: MoreHorizontal },
];

const SIZES = [
  { label: "1-10 personas", sublabel: "Emprendimiento / Startup", value: "micro" },
  { label: "11-50 personas", sublabel: "Pequeña empresa", value: "small" },
  { label: "51-200 personas", sublabel: "Empresa mediana", value: "medium" },
  { label: "200+ personas", sublabel: "Corporación", value: "large" },
];

const MATURITY_LEVELS = [
  {
    value: "basico",
    label: "Básico",
    description: "Usamos herramientas digitales básicas (email, Excel, redes).",
    color: "from-orange-400 to-red-400",
  },
  {
    value: "intermedio",
    label: "Intermedio",
    description: "Tenemos algunos sistemas pero no están integrados entre sí.",
    color: "from-yellow-400 to-orange-400",
  },
  {
    value: "avanzado",
    label: "Avanzado",
    description: "Usamos tecnología activamente pero queremos escalar.",
    color: "from-blue-400 to-cyan-400",
  },
  {
    value: "nativo",
    label: "Nativo Digital",
    description: "Somos digitales por naturaleza y buscamos optimizar.",
    color: "from-violet-400 to-blue-400",
  },
];

const GOALS = [
  { value: "procesos", label: "Automatizar procesos internos", icon: Target },
  { value: "ventas", label: "Aumentar ventas digitales", icon: TrendingUp },
  { value: "datos", label: "Tomar mejores decisiones con datos", icon: BarChart3 },
  { value: "producto", label: "Lanzar un producto / servicio digital", icon: Zap },
  { value: "cultura", label: "Transformar la cultura organizacional", icon: Users },
  { value: "expansion", label: "Expandirme a nuevos mercados", icon: Globe2 },
];

// ─── step config ─────────────────────────────────────────────────────────────

const TOTAL_STEPS = 5;

// ─── floating paths (reused from hero) ───────────────────────────────────────

function FloatingPaths({ position }: { position: number }) {
  const paths = Array.from({ length: 24 }, (_, i) => ({
    id: i,
    d: `M-${380 - i * 5 * position} -${189 + i * 6}C-${380 - i * 5 * position} -${189 + i * 6} -${312 - i * 5 * position} ${216 - i * 6} ${152 - i * 5 * position} ${343 - i * 6}C${616 - i * 5 * position} ${470 - i * 6} ${684 - i * 5 * position} ${875 - i * 6} ${684 - i * 5 * position} ${875 - i * 6}`,
    width: 0.5 + i * 0.03,
  }));
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <svg className="w-full h-full text-slate-950 dark:text-white opacity-[0.04]" viewBox="0 0 696 316" fill="none">
        {paths.map((p) => (
          <motion.path
            key={p.id}
            d={p.d}
            stroke="currentColor"
            strokeWidth={p.width}
            initial={{ pathLength: 0.3, opacity: 0.6 }}
            animate={{ pathLength: 1, opacity: [0.3, 0.6, 0.3], pathOffset: [0, 1, 0] }}
            transition={{ duration: 20 + p.id * 0.5, repeat: Infinity, ease: "linear" }}
          />
        ))}
      </svg>
    </div>
  );
}

// ─── progress bar ─────────────────────────────────────────────────────────────

function ProgressBar({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
        <div key={i} className="flex items-center gap-2">
          <motion.div
            animate={{
              width: i < step ? 32 : i === step - 1 ? 32 : 8,
              backgroundColor: i < step ? "#2563eb" : i === step - 1 ? "#2563eb" : "#e5e7eb",
            }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="h-2 rounded-full"
            style={{ width: 8 }}
          />
        </div>
      ))}
      <span className="text-xs text-neutral-400 ml-2 font-medium tabular-nums">
        {step}/{TOTAL_STEPS}
      </span>
    </div>
  );
}

// ─── slide animation ──────────────────────────────────────────────────────────

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? 60 : -60, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir > 0 ? -60 : 60, opacity: 0 }),
};

// ─── main component ───────────────────────────────────────────────────────────

export default function OnboardingForm() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [dir, setDir] = useState(1);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState<FormData>({
    companyName: "",
    country: "",
    industry: "",
    companySize: "",
    digitalMaturity: "",
    mainGoal: "",
    contactName: "",
    contactEmail: "",
  });

  const set = (k: keyof FormData, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const next = () => { setDir(1); setStep((s) => Math.min(s + 1, TOTAL_STEPS)); };
  const back = () => { setDir(-1); setStep((s) => Math.max(s - 1, 1)); };

  const canNext = () => {
    if (step === 1) return form.companyName.trim().length > 0 && form.country;
    if (step === 2) return !!form.industry;
    if (step === 3) return !!form.companySize;
    if (step === 4) return !!form.digitalMaturity && !!form.mainGoal;
    if (step === 5) return form.contactName.trim().length > 0 && /\S+@\S+\.\S+/.test(form.contactEmail);
    return false;
  };

  const submit = () => setDone(true);

  return (
    <div className="relative min-h-screen bg-white dark:bg-neutral-950 flex flex-col">
      {/* background */}
      <FloatingPaths position={1} />
      <FloatingPaths position={-1} />

      {/* nav */}
      <header className="relative z-10 flex items-center justify-between px-6 py-5 border-b border-neutral-100 dark:border-neutral-800">
        <button
          onClick={() => router.push("/")}
          className="flex items-center gap-2 font-bold text-lg text-neutral-900 dark:text-white"
        >
          <div className="w-7 h-7 bg-gradient-to-br from-blue-600 to-violet-600 rounded-lg flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          Momentum<span className="text-blue-600">Lab</span>
        </button>
        {!done && <ProgressBar step={step} />}
      </header>

      {/* content */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-xl">
          <AnimatePresence mode="wait" custom={dir}>
            {done ? (
              <motion.div
                key="done"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 20 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-violet-600 mb-6 shadow-lg shadow-blue-500/30">
                  <CheckCircle2 className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-neutral-900 dark:text-white mb-3">
                  ¡Todo listo, {form.contactName.split(" ")[0]}!
                </h2>
                <p className="text-neutral-500 dark:text-neutral-400 mb-2">
                  Recibimos la información de{" "}
                  <span className="font-semibold text-neutral-700 dark:text-neutral-200">
                    {form.companyName}
                  </span>
                  .
                </p>
                <p className="text-neutral-500 dark:text-neutral-400 mb-10">
                  Vamos a enviarte un diagnóstico digital personalizado a{" "}
                  <span className="text-blue-600 font-medium">{form.contactEmail}</span> en menos de
                  24 hs.
                </p>
                <Button
                  onClick={() => router.push("/")}
                  className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white border-0 px-8 py-3 rounded-xl"
                >
                  Volver al inicio
                </Button>
              </motion.div>
            ) : (
              <motion.div
                key={step}
                custom={dir}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
              >
                <StepContent step={step} form={form} set={set} />

                {/* nav buttons */}
                <div className="flex items-center justify-between mt-10">
                  <Button
                    variant="ghost"
                    onClick={back}
                    disabled={step === 1}
                    className="gap-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-white disabled:opacity-0"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Atrás
                  </Button>

                  {step < TOTAL_STEPS ? (
                    <Button
                      onClick={next}
                      disabled={!canNext()}
                      className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white border-0 px-6 py-2.5 rounded-xl disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Continuar
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      onClick={submit}
                      disabled={!canNext()}
                      className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white border-0 px-6 py-2.5 rounded-xl disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Enviar diagnóstico
                      <CheckCircle2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

// ─── step content ─────────────────────────────────────────────────────────────

function StepContent({
  step,
  form,
  set,
}: {
  step: number;
  form: FormData;
  set: (k: keyof FormData, v: string) => void;
}) {
  if (step === 1) return <Step1 form={form} set={set} />;
  if (step === 2) return <Step2 form={form} set={set} />;
  if (step === 3) return <Step3 form={form} set={set} />;
  if (step === 4) return <Step4 form={form} set={set} />;
  return <Step5 form={form} set={set} />;
}

// ─── shared input style ───────────────────────────────────────────────────────

const inputClass =
  "w-full px-4 py-3 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800/60 text-neutral-900 dark:text-white placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition text-sm";

// ─── step 1 — empresa + país ──────────────────────────────────────────────────

function Step1({ form, set }: { form: FormData; set: (k: keyof FormData, v: string) => void }) {
  return (
    <div>
      <StepHeader
        icon={<Building2 className="w-5 h-5 text-blue-600" />}
        label="Tu empresa"
        title="¿Cómo se llama tu empresa y dónde operás?"
        subtitle="Comenzamos con lo básico para entender tu contexto."
      />
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
            Nombre de la empresa
          </label>
          <input
            type="text"
            value={form.companyName}
            onChange={(e) => set("companyName", e.target.value)}
            placeholder="Ej: Acme S.A."
            className={inputClass}
            autoFocus
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
            País
          </label>
          <div className="relative">
            <Globe2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" />
            <select
              value={form.country}
              onChange={(e) => set("country", e.target.value)}
              className={cn(inputClass, "pl-10 appearance-none cursor-pointer")}
            >
              <option value="">Seleccioná tu país</option>
              {COUNTRIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── step 2 — rubro ───────────────────────────────────────────────────────────

function Step2({ form, set }: { form: FormData; set: (k: keyof FormData, v: string) => void }) {
  return (
    <div>
      <StepHeader
        icon={<BarChart3 className="w-5 h-5 text-blue-600" />}
        label="Rubro"
        title="¿En qué industria operás?"
        subtitle="Esto nos permite preparar un diagnóstico más preciso."
      />
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {INDUSTRIES.map(({ label, icon: Icon }) => (
          <button
            key={label}
            onClick={() => set("industry", label)}
            className={cn(
              "flex flex-col items-center gap-2 p-4 rounded-2xl border-2 text-sm font-medium transition-all duration-200 hover:-translate-y-0.5",
              form.industry === label
                ? "border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400"
                : "border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:border-blue-300 dark:hover:border-blue-700 bg-white dark:bg-neutral-800/40"
            )}
          >
            <Icon className="w-5 h-5" />
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── step 3 — tamaño ──────────────────────────────────────────────────────────

function Step3({ form, set }: { form: FormData; set: (k: keyof FormData, v: string) => void }) {
  return (
    <div>
      <StepHeader
        icon={<Users className="w-5 h-5 text-blue-600" />}
        label="Equipo"
        title="¿Cuántas personas trabajan en tu empresa?"
        subtitle="El tamaño del equipo define el alcance y el enfoque."
      />
      <div className="space-y-3">
        {SIZES.map(({ label, sublabel, value }) => (
          <button
            key={value}
            onClick={() => set("companySize", value)}
            className={cn(
              "w-full flex items-center justify-between px-5 py-4 rounded-2xl border-2 text-left transition-all duration-200",
              form.companySize === value
                ? "border-blue-600 bg-blue-50 dark:bg-blue-950/40"
                : "border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 hover:border-blue-300 dark:hover:border-blue-700"
            )}
          >
            <div>
              <div className={cn("font-semibold text-sm", form.companySize === value ? "text-blue-700 dark:text-blue-300" : "text-neutral-900 dark:text-white")}>
                {label}
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">{sublabel}</div>
            </div>
            <div className={cn(
              "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors",
              form.companySize === value ? "border-blue-600 bg-blue-600" : "border-neutral-300 dark:border-neutral-600"
            )}>
              {form.companySize === value && <div className="w-2 h-2 rounded-full bg-white" />}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── step 4 — madurez + objetivo ──────────────────────────────────────────────

function Step4({ form, set }: { form: FormData; set: (k: keyof FormData, v: string) => void }) {
  return (
    <div className="space-y-8">
      {/* madurez digital */}
      <div>
        <StepHeader
          icon={<TrendingUp className="w-5 h-5 text-blue-600" />}
          label="Diagnóstico"
          title="¿Cuál es tu nivel de madurez digital actual?"
          subtitle="Elegí la opción que mejor describe a tu empresa hoy."
        />
        <div className="grid grid-cols-2 gap-3">
          {MATURITY_LEVELS.map(({ value, label, description, color }) => (
            <button
              key={value}
              onClick={() => set("digitalMaturity", value)}
              className={cn(
                "text-left p-4 rounded-2xl border-2 transition-all duration-200",
                form.digitalMaturity === value
                  ? "border-blue-600 bg-blue-50 dark:bg-blue-950/40"
                  : "border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 hover:border-blue-300"
              )}
            >
              <div className={cn("text-xs font-bold bg-gradient-to-r bg-clip-text text-transparent mb-1", color)}>
                {label}
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                {description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* objetivo */}
      <div>
        <p className="text-sm font-semibold text-neutral-700 dark:text-neutral-300 mb-3">
          ¿Cuál es tu principal objetivo?
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {GOALS.map(({ value, label, icon: Icon }) => (
            <button
              key={value}
              onClick={() => set("mainGoal", value)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left text-sm font-medium transition-all duration-200",
                form.mainGoal === value
                  ? "border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300"
                  : "border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 text-neutral-600 dark:text-neutral-400 hover:border-blue-300"
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── step 5 — contacto ────────────────────────────────────────────────────────

function Step5({ form, set }: { form: FormData; set: (k: keyof FormData, v: string) => void }) {
  return (
    <div>
      <StepHeader
        icon={<CheckCircle2 className="w-5 h-5 text-blue-600" />}
        label="Último paso"
        title="¿A quién le mandamos el diagnóstico?"
        subtitle="Te enviamos un análisis personalizado en menos de 24 hs."
      />

      {/* summary card */}
      <div className="mb-6 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-700">
        <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Resumen</p>
        <div className="flex flex-wrap gap-2">
          {[
            form.companyName,
            form.country,
            form.industry,
            SIZES.find((s) => s.value === form.companySize)?.label,
            MATURITY_LEVELS.find((m) => m.value === form.digitalMaturity)?.label,
            GOALS.find((g) => g.value === form.mainGoal)?.label,
          ]
            .filter(Boolean)
            .map((tag, i) => (
              <span
                key={i}
                className="text-xs px-2.5 py-1 bg-white dark:bg-neutral-700 border border-neutral-200 dark:border-neutral-600 rounded-full text-neutral-600 dark:text-neutral-300"
              >
                {tag}
              </span>
            ))}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
            Tu nombre
          </label>
          <input
            type="text"
            value={form.contactName}
            onChange={(e) => set("contactName", e.target.value)}
            placeholder="Ej: María García"
            className={inputClass}
            autoFocus
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1.5">
            Email de contacto
          </label>
          <input
            type="email"
            value={form.contactEmail}
            onChange={(e) => set("contactEmail", e.target.value)}
            placeholder="tu@empresa.com"
            className={inputClass}
          />
        </div>
        <p className="text-xs text-neutral-400 dark:text-neutral-500">
          Tu información está segura. No la compartimos con terceros.
        </p>
      </div>
    </div>
  );
}

// ─── step header ──────────────────────────────────────────────────────────────

function StepHeader({
  icon,
  label,
  title,
  subtitle,
}: {
  icon: React.ReactNode;
  label: string;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="mb-7">
      <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-600 uppercase tracking-widest mb-3 bg-blue-50 dark:bg-blue-950/40 px-3 py-1.5 rounded-full border border-blue-100 dark:border-blue-900">
        {icon}
        {label}
      </div>
      <h2 className="text-2xl sm:text-3xl font-bold text-neutral-900 dark:text-white mb-2 leading-tight">
        {title}
      </h2>
      <p className="text-neutral-500 dark:text-neutral-400 text-sm">{subtitle}</p>
    </div>
  );
}
